//***********************************************************************************
// This simplified sketch controls relays connected to shift registers.
// It seves as a verification mechanism that the correct relays are activated.
//***********************************************************************************

// Define the GPIO pins connected to the shift registers
const int ClockPin = 2; // SRCLK - Serial Clock
const int LatchPin = 3; // RCLK - Register Clock (Latching data to output)
const int ClearPin = 4; // *SRCLR - Serial Clear (active LOW)
const int DataPin = 5;  // SER - Serial Data Input

// This array holds the 16-bit commands for the relays.
// Each command activates a different set of relays.
const uint16_t RelayData[13] = {
  0x8008, 0x0108, 0x0210, 0x0410, 0x0810, 0x1010, 0x2010,
  0x4010, 0x0090, 0x0011, 0x0011, 0x0072, 0x0072
};


// This function clears the shift registers, turning off all relays.
void clearRegisters() {
  digitalWrite(ClearPin, LOW);  // Set the clear pin LOW to activate the clear function
  delay(10);                    // A small delay is enough
  digitalWrite(ClearPin, HIGH); // Set back to HIGH for normal operation
}


// This function sends the selected 16-bit command to the two shift registers.
void updateShiftRegister(int pinIndex) {
  // Get the 16-bit command from our data array
  uint16_t command = RelayData[pinIndex];

  // Pull the latch pin LOW while we are sending data
  digitalWrite(LatchPin, LOW);
  
  // Prints out the highbyte and lowbyte data to identify the shift register activated
  Serial.println("Highbyte is:");
  Serial.println(highByte(command), BIN);
  Serial.println("Lowbyte is:");
  Serial.println(lowByte(command), BIN);

  // Send the high byte to U1
  shiftOut(DataPin, ClockPin, LSBFIRST, lowByte(command)); 
  // Send the low byte TO U14
  shiftOut(DataPin, ClockPin, LSBFIRST, highByte(command)); 

  // Pull the latch pin HIGH to transfer the data from the shift register
  // to the output pins, activating the relays.
  digitalWrite(LatchPin, HIGH);
}


void setup() {
  // Start Serial communication so we can see status messages in the Serial Monitor
  Serial.begin(9600);
  Serial.println("Relay control sketch initialized.");

  // Set up the shift register pins as outputs
  pinMode(LatchPin, OUTPUT);
  pinMode(DataPin, OUTPUT);
  pinMode(ClockPin, OUTPUT);
  pinMode(ClearPin, OUTPUT);

  // The Clear pin must be HIGH for the shift registers to work.
  digitalWrite(ClearPin, HIGH);
  
  // Clear the registers at the start to ensure all relays are off.
  clearRegisters();
  Serial.println("Shift registers cleared on startup. All relays are OFF.");

  int commandToSend = 12; // <<-- CHANGE THIS NUMBER (0-12) to select a different relay pattern.
  Serial.print("Activating relay pattern #");
  Serial.print(commandToSend);
  Serial.println(" for 30 seconds...");
  
  updateShiftRegister(commandToSend);
}


void loop() {}
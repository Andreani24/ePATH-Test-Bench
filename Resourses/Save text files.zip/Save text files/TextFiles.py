import tkinter as tk
from tkinter import filedialog
from tkinter import messagebox
import serial
import serial.tools.list_ports
import time
data=[]
clear_press=False
save_press=False


#Function that find the computer port connected to the Arduino
def find_arduino_port():
    ports = serial.tools.list_ports.comports()
    for port in ports:
        if "Arduino" in port.description:  # Check if "Arduino" is in the port description
            return port.device
    return None


# Function to initialise the Arduino. The default is 9600 baud rate
def initialize_arduino(baudrate=9600):
    try:
        port=find_arduino_port()
        ser = serial.Serial(port, baudrate, timeout=1)
        time.sleep(2)  # Wait for Arduino to initialize
        return ser
    except serial.SerialException as e:
        messagebox.showerror('Error', f'Failed to connect to Arduino: {e}')
        return None


# Function to receive responses from Arduino.
# Has additional checks which prevent the response to be an empty string.
def receive_response(timeout=3):
    global arduino
    start_time = time.time()

    while True:
        try:
            # Check if data is available
            if arduino.in_waiting > 0:
                response = arduino.readline().decode('utf-8').strip()

                # Return if we got a non-empty response
                if response:
                    return response

            # Check if timeout has been exceeded
            if time.time() - start_time > timeout:
                raise RuntimeError("Timeout waiting for response from Arduino")

            # Small delay to prevent CPU overload
            time.sleep(0.01)

        except Exception as e:
            messagebox.showerror('Communication Error', f'Could not receive response: {str(e)}')
            raise  # Re-raise the exception after showing the messagebox


# Function that receives and saves the data from the Arduino
# It loops continuously to receive all responses
def loop_until_save():
    global data
    response = receive_response()
    data.append(response)
    queue_listbox.insert("end", response)
    root.after(500, loop_until_save)  # Run again in 500 ms


# Function that defines what happens when you press the Save button
# It saves the data received until now in a text file
def on_save():
    global data,save_press
    if save_press:
        return
    save_press=True
    file_path = filedialog.asksaveasfilename(
        defaultextension=".txt",
        filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")],
        title="Save Experiment as Text File"
    )

    if file_path:
        try:
            with open(file_path, 'w') as file:
                file.write("\n".join(data))

        except Exception as e:
            messagebox.showerror("Error", f"Failed to save file:\n{e}")

    data=[]
    queue_listbox.delete(0, 'end')
    root.update_idletasks()
    save_press=False


# Function that defines what happens when you press the Clear button
# The data in the listbox and the text file are deleted
def clear_data():
    global clear_press,data
    if clear_press:  # Prevents double clicking
        return
    clear_press = True
    data=[]
    queue_listbox.delete(0, 'end')
    root.update_idletasks()
    clear_press = False


# Function that defines what happens when you press the i button
# It shows an information display explaining GUI functionalities
def info_display():
    overlay_frame = tk.Frame(root, bg="#ADD8E6", width=1350, height=900)
    overlay_frame.place(relx=0.05, rely=0.05, relwidth=0.85, relheight=0.65)

    root.after(100, lambda: overlay_frame.lift())

    instructions_label = tk.Label(overlay_frame, text="Welcome to Mamadou's GUI!\n\n"
                                                     "Just connect an Arduino to your PC and any information\n printed on the Serial monitor will be captured and displayed.\n"
                                                     "Press Save to save the data in a text file.\n"
                                                     "If the data was unsatisfactory delete it by pressing clear.\n"
                                                     "\nClick 'OK' to continue.",
                             font=("Helvetica", 16), bg="#ADD8E6", justify="center",anchor="center")
    instructions_label.pack(pady=40)

    ok_button = tk.Button(overlay_frame, text="OK", command=overlay_frame.destroy,
                          bg="gray", fg="white", font=("Helvetica", 14), width=4)
    ok_button.pack(pady=(0, 10))




# Initializes the page
root = tk.Tk()
root.title('Text file saving software')
root.geometry('700x500')
root.configure(bg="white")

# Initializes Arduino
arduino = initialize_arduino()

# Place the buttons in position
save_button = tk.Button(root, text="Save", command=on_save, bg="blue", fg="white",
                        font=("Helvetica", 14), width=6)
save_button.place(relx=0.3, rely=0.85, anchor="center")
clear_button = tk.Button(root, text="Clear all", command=clear_data, bg="red", fg="white",
                         font=("Helvetica", 14), width=8)
clear_button.place(relx=0.7, rely=0.85, anchor="center")
info_button = tk.Button(root, text="i", command=info_display, bg="gray", fg="white",
                         font=("Helvetica", 12), width=1)
info_button.place(relx=0.017, rely=0.04, anchor="center")

# Make queue listbox
queue_listbox = tk.Listbox(root, font=("Helvetica", 12), height=18, width=71, selectmode=tk.SINGLE)
queue_listbox.place(relx=0.5, rely=0.4, anchor="center")  # Adjusts dynamically

loop_until_save()
root.mainloop()
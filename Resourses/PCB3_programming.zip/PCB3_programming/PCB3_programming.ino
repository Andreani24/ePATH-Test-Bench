//***********************************************************************************
// This sketch controls a PCB to do automated tests on the ePATH board.
// It utilises shift registers to send commands to relays that select the appropriate
// pin to be tested. A multimeter is used to perform the measurements. Some other
// features of the sketch include a potentiometer, a PN532 module and a button.
// The sketch is compatible with a GUI as it prints the pin number, measurement 
// and result on the Serial monitor.
//***********************************************************************************

//Shift registers setup
const int ClockPin = 2; //SRCLK
const int LatchPin = 3;  //RCLK
const int ClearPin = 4;  //*SRCLR
const int DataPin = 5;  //SER
//Digital potentiometer setup
const int ChipSelect = 49;  //CS
const int SerialClock = 51;  //SCK
const int SerialIn = 53;  //SI
const byte commandByte = B00010001; // The command byte for your potentiometer to "Write Data to Potentiometer 0"
//PN532 setup
#include <Wire.h>
#include <PN532_I2C.h>
#include <PN532.h>
#include <NfcAdapter.h>
PN532_I2C pn532i2c(Wire1); // I use Wire1 instead of Wire because I connected t SDA1/SCL1 instead of SCL21/SDA20
PN532 nfc(pn532i2c);
// General setup
const int buttonPin = 13;
int buttonState ;
String command;
String response;
float target_range[2];
// Define relay on/off patterns as an array using hexadecimals.
const uint16_t RelayData[13] = {
  0x8008, 0x0108, 0x0210, 0x0410, 0x0810, 0x1010, 0x2010,
  0x4010, 0x0090, 0x0011, 0x0011, 0x0072, 0x0072};


// This helper function checks for a "STOP" command and updates the global 'command' variable.
// It returns true if a stop command was received, otherwise false.
bool checkStopCommand() {
  if (Serial.available()) {
    String input = Serial.readStringUntil('\n');
    input.trim();
    if (input == "STOP") {
      command = "STOP"; 
      return true;
    }
  }
  return false;
}


// This helper function sends one byte of data using Software SPI
void software_spi_transfer(byte data) {
  // Send 8 bits of data, starting with the Most Significant Bit (MSB)
  for (int i = 7; i >= 0; i--) {
    // 1. Set the clock pin LOW
    digitalWrite(SerialClock, LOW);

    // 2. Set the data pin to the current bit's value
    if (bitRead(data, i) == 1) {
      digitalWrite(SerialIn, HIGH);
    } else {
      digitalWrite(SerialIn, LOW);
    }

    // 3. Set the clock pin HIGH to signal the potentiometer to read the bit
    digitalWrite(SerialClock, HIGH);
  }
}

// This function controls the potentiometer using Software SPI
// This function makes the potentiometer take the appropriate resistance value. 
// There are 256 wiper positions so you can select from 0 to 255 to set the resistance. 
void write_digipot(int val) {
  // 1. Take the CS pin low to select the chip
  digitalWrite(ChipSelect, LOW);

  // 2. Send the command byte
  software_spi_transfer(commandByte);

  // 3. Send the value byte
  software_spi_transfer(val);

  // 4. Take the CS pin high to de-select the chip
  digitalWrite(ChipSelect, HIGH);
}


// This function sends commands to the potentiomer according to the test number
// so that it takes the appropriate resistance value
void potentiometer_command(int pin)
{
  if (pin >= 0 && pin <= 10){}
  else if (pin==11)
  {
    write_digipot(233);  // Sets the resistance to approx 1kOhm
    delay(1000);
  }
  else if (pin==12)
  {
    write_digipot(244);   // Sets the resistance to approx 560Ohm
    delay(1000);
  }
  else
  {
    Serial.print("Error sending commands to potentiometer");
  }
}


// This function clears the shift registers.
void Clear()
{
  digitalWrite(ClearPin, LOW);
  delay(1000);
  digitalWrite(ClearPin, HIGH);
}


// This function sends the data to the shift registers through shiftout and then latchs them.
// It send 16 bits of information split into 2 8-bit sets.
void updateShiftRegister(int pinIndex) {
  // Get the 16-bit command from our data array
  uint16_t command = RelayData[pinIndex];

  // Pull the latch pin LOW while we are sending data
  digitalWrite(LatchPin, LOW);

  // Send the high byte to U1
  shiftOut(DataPin, ClockPin, LSBFIRST, lowByte(command)); 
  // Send the low byte TO U14
  shiftOut(DataPin, ClockPin, LSBFIRST, highByte(command)); 

  // Pull the latch pin HIGH to transfer the data from the shift register
  // to the output pins, activating the relays.
  digitalWrite(LatchPin, HIGH);
}




// This function reads the RFID of the ePATH board.
// It was obtained from an example sketch from the PN532 library named iso14443a_uid.
void PN532()
{
  nfc.begin();
  uint32_t versiondata = nfc.getFirmwareVersion();
  // Checks if PN532 board is well connected. If not it halts the program
  if (! versiondata) {
    Serial.print("ERROR");
    return; // halt
  }
  // Set the max number of retry attempts to read from a card
  // This prevents us from waiting forever for a card, which is
  // the default behaviour of the PN532.
  nfc.setPassiveActivationRetries(0xFF);
  
  // configure board to read RFID tags
  nfc.SAMConfig();
    
  boolean success;
  uint8_t uid[] = { 0, 0, 0, 0, 0, 0, 0 };  // Buffer to store the returned UID
  uint8_t uidLength;                        // Length of the UID (4 or 7 bytes depending on ISO14443A card type)
  
  // Wait for an ISO14443A type cards (Mifare, etc.).  
  success = nfc.readPassiveTargetID(PN532_MIFARE_ISO14443A, &uid[0], &uidLength);
  
  if (success) {
    for (uint8_t i=0; i < uidLength; i++) 
    {
      Serial.print(" 0x");Serial.print(uid[i], HEX); 
    }
    Serial.println();
    delay(1000);
  }
  else
  {
    // PN532 probably timed out waiting for a card
    Serial.println("ERROR");
  }
}


// This function sends the appropriate command to the multimeter according to the test number.
void command_sending(int pin)
{
  if (pin >= 0 && pin <= 8)
  {
    Serial1.print("MEAS:VOLT:DC?\r\n");
    delay(2000);
  }
  else if (pin==9)
  {
    Serial1.print("MEAS:FREQ?\r\n");
    delay(3000);
  }
  else if (pin >= 10 && pin <= 12)
  {
    Serial1.print("MEAS:VOLT:AC?\r\n");
    delay(2000);
  }
  else
  {
    Serial.print("Error selecting the pin");
  }
}


// This function tells you the allowable voltage range according to the test number.
void target_ranges(int pin)
{  
  if (pin == 0)
  { 
    target_range[0]=4.25;
    target_range[1]=5.75;
  }
  else if (pin==1 || pin==2 || pin==6)
  { 
    target_range[0]=4.5;
    target_range[1]=5.5;
  }
  else if (pin ==4)
  { 
    target_range[0]=2.97;
    target_range[1]=3.63;
  }
  else if (pin==3 || pin==5 )
  { 
    target_range[0]=-4.5;
    target_range[1]=-5.5;
  }
  else if (pin ==7)
  { 
    target_range[0]=4.01408;
    target_range[1]=4.17792;
  }
  else if (pin ==8)
  { 
    target_range[0]=2.375;
    target_range[1]=2.625;
  }
  else if (pin ==9)
  { 
    target_range[0]=24987.6;
    target_range[1]=25492.4;
  }
  else if (pin ==10)
  { 
    target_range[0]=1.98;
    target_range[1]=2.42;
  }
  else if (pin ==11)
  { 
    target_range[0]=7.6;
    target_range[1]=8.4;
  }
  else if (pin ==12)
  { 
    target_range[0]=5.32;
    target_range[1]=5.88;
  }
}


// This function tell you whether the test was succesful or not.
// It checks if the measured value received is within the target range.
void voltage_check(int pin, float voltage)
{ 
    target_ranges(pin);
    if (voltage>target_range[0] && voltage<target_range[1])
    {
      Serial.println("PASS");
    }
    else
    {
      Serial.println("FAIL");
    }
}


void setup() 
{ Serial.begin(9600);    // Start USB serial communication (Serial Monitor)
  Serial1.begin(9600);   // Start Hardware communication (pins 18 and 19)
  // Set up the selected pins of the shift registers as outputs or inputs
  pinMode(LatchPin, OUTPUT);
  digitalWrite(LatchPin, LOW);
  pinMode(DataPin, OUTPUT);
  digitalWrite(DataPin, LOW);
  pinMode(ClockPin, OUTPUT);
  digitalWrite(ClockPin, LOW);
  pinMode(ClearPin, OUTPUT);
  // Clear the Shift regisers
  Clear();
 
  // Set up the selected pins of the potentiometer as outputs or inputs
  // Set all our custom SPI pins to outputs
  pinMode(ChipSelect, OUTPUT);
  pinMode(SerialClock, OUTPUT);
  pinMode(SerialIn, OUTPUT);

  // Set initial states
  digitalWrite(ChipSelect, HIGH); // Chip should be de-selected initially
  digitalWrite(SerialClock, LOW); // Clock should be idle-low for SPI Mode 0


  pinMode(buttonPin, INPUT);
  
  // Multimeter setup
  Serial1.print("*RST\r\n");
  delay(1000);                                                         
  Serial1.print("*CLS\r\n");
  delay(1000);
  Serial1.print("SYST:REM\r\n");
  delay(1000);
  

}


void loop() 
{
  // Checks is there are any comments sent over the serial monitor  
  if (Serial.available()) {
    command = Serial.readStringUntil('\n');
    command.trim();
    if (command=="START" || command == "STOP"){}
    else if (command=="GET"){PN532();}
    else if (command=="*IDN?"){
      Serial1.println(command);               
      delay(1000);
      response = Serial1.readStringUntil('\n');
      Serial.println(response);
    }
    else {
      Serial1.println(command);           
      delay(1000);
    }
  }

  // Checks whether the test should start.
  // If the button is pressed or you send 'START' then start.
  buttonState = digitalRead(buttonPin);
  if (buttonState == LOW || command == "START") 
  {
    command="";
    Clear();
    delay(50);
        
    // Iterate through all the tests that need to be performed.
    for (int pin=0; pin<=12; pin++)
    { // Ensures that no stop command has been sent.
      if (checkStopCommand()) {break;}

      
      // I update the relays for the particular test
      updateShiftRegister(pin);

      if (checkStopCommand()) {break;}
      // I make the potentiometer take the appropriate resistance
      potentiometer_command(pin);
      // I send a command about the measurement I want to make according to the pin number
      command_sending(pin);
      if (checkStopCommand()) {break;}

      // I read the multimeter response
      if (Serial1.available()) 
      {
        Serial.println(pin);
        response = Serial1.readStringUntil('\n');
        float response_num= response.toFloat();
        // When doing voltage AC readings the voltmeter finds RMS values. I convertt hat to a peak-to-peak value.
        if (pin == 10 || pin == 11 || pin == 12) {
          response_num = response_num * 2.8284271247461903;}


        delay(1000);
        // Tells you the voltage and the pin number
        Serial.println(response_num);
        delay(1000);
        // Tells you whether the test was succesful
        voltage_check(pin,response_num);
        if (checkStopCommand()) {break;}
      }
      else 
      {
           Serial.print("ERROR:No data was received from pin ");
          Serial.print(pin);
          break;
      }
      
    } 
  }
}

